"""Transport-neutral protocol v1 data transfer objects.

These DTOs deliberately contain only JSON values. Pyrogram, Telethon, Aiogram,
and other Telegram-library types must never cross the plugin boundary.
"""

from __future__ import annotations

import dataclasses
import enum
import json
from collections.abc import Mapping, Sequence
from typing import Any

from .errors import ProtocolError

PROTOCOL_NAME = "serenox.plugin/1"
PROTOCOL_VERSION = "1.0"
SDK_VERSION = "0.1.0"
JSONValue = None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]


class HandlerKind(str, enum.Enum):
    COMMAND = "command"
    WATCHER = "watcher"
    INLINE = "inline"
    CALLBACK = "callback"


class ActionKind(str, enum.Enum):
    REPLY = "message.reply"
    EDIT = "message.edit"
    DELETE = "message.delete"
    SEND = "client.send_message"
    GET_MESSAGE = "client.get_message"
    GET_ME = "client.get_me"
    RESOLVE_PEER = "client.resolve_peer"
    JOIN_CHAT = "client.join_chat"
    LEAVE_CHAT = "client.leave_chat"
    REACT = "client.react"
    INLINE_ANSWER = "inline.answer"
    INLINE_FORM = "inline.form"
    INLINE_EDIT = "inline.edit"
    INLINE_DELETE = "inline.delete"
    STORAGE_GET = "storage.get"
    STORAGE_SET = "storage.set"
    STORAGE_DELETE = "storage.delete"
    INVOKE_COMMAND = "command.invoke"


def ensure_json_value(value: Any, *, field: str = "value") -> JSONValue:
    """Return *value* after strict, bounded-protocol-compatible type checking."""

    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ProtocolError(f"{field} must not contain NaN or infinity")
        return value
    if isinstance(value, (list, tuple)):
        return [ensure_json_value(item, field=f"{field}[]") for item in value]
    if isinstance(value, Mapping):
        result: dict[str, JSONValue] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise ProtocolError(f"{field} object keys must be strings")
            result[key] = ensure_json_value(item, field=f"{field}.{key}")
        return result
    raise ProtocolError(f"{field} contains unsupported value type {type(value).__name__}")


def _drop_none(value: Any) -> JSONValue:
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return _drop_none(dataclasses.asdict(value))
    if isinstance(value, enum.Enum):
        return ensure_json_value(value.value)
    if isinstance(value, Mapping):
        return {str(key): _drop_none(item) for key, item in value.items() if item is not None}
    if isinstance(value, (list, tuple)):
        return [_drop_none(item) for item in value]
    return ensure_json_value(value)


@dataclasses.dataclass(frozen=True, slots=True)
class RPCErrorV1:
    code: str
    message: str
    retryable: bool = False
    details: Mapping[str, JSONValue] = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="error"))

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> RPCErrorV1:
        return cls(
            code=_require_str(value.get("code"), "error.code"),
            message=_require_str(value.get("message"), "error.message"),
            retryable=_optional_bool(value.get("retryable"), False, "error.retryable"),
            details=_require_object(value.get("details", {}), field="error.details"),
        )


@dataclasses.dataclass(frozen=True, slots=True)
class EnvelopeV1:
    request_id: int
    kind: str
    payload: Mapping[str, JSONValue] = dataclasses.field(default_factory=dict)
    deadline_unix_ms: int = 0
    method: str | None = None
    result: Mapping[str, JSONValue] | None = None
    error: RPCErrorV1 | None = None
    protocol: str = PROTOCOL_NAME

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="envelope"))

    def to_json(self) -> bytes:
        return json.dumps(
            self.to_dict(), ensure_ascii=False, allow_nan=False, separators=(",", ":")
        ).encode("utf-8")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> EnvelopeV1:
        protocol = _require_str(value.get("protocol"), "protocol")
        if protocol != PROTOCOL_NAME:
            raise ProtocolError(
                f"unsupported protocol {protocol!r}; this sidecar supports {PROTOCOL_NAME!r}"
            )
        error_value = value.get("error")
        request_id = _require_int(value.get("request_id"), "request_id")
        if request_id <= 0:
            raise ProtocolError("request_id must be positive")
        return cls(
            protocol=protocol,
            request_id=request_id,
            kind=_require_str(value.get("kind"), "kind"),
            deadline_unix_ms=_optional_int(value.get("deadline_unix_ms"), 0, "deadline_unix_ms"),
            method=_nullable_str(value.get("method"), "method"),
            payload=_require_object(value.get("payload", {}), field="payload"),
            result=(
                _require_object(value.get("result"), field="result")
                if value.get("result") is not None
                else None
            ),
            error=(
                RPCErrorV1.from_dict(_require_object(error_value, field="error"))
                if error_value is not None
                else None
            ),
        )

    @classmethod
    def from_json(cls, data: bytes) -> EnvelopeV1:
        try:
            value = json.loads(data)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ProtocolError(f"malformed JSON frame: {exc}") from exc
        return cls.from_dict(_require_object(value, field="envelope"))


@dataclasses.dataclass(frozen=True, slots=True)
class HandlerSpecV1:
    kind: HandlerKind
    name: str
    method: str
    filters: Mapping[str, JSONValue] = dataclasses.field(default_factory=dict)
    aliases: Sequence[str] = dataclasses.field(default_factory=tuple)
    timeout_ms: int = 10_000

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="handler"))


@dataclasses.dataclass(frozen=True, slots=True)
class PluginMetadataV1:
    name: str
    version: str
    description: str
    handlers: Sequence[HandlerSpecV1]
    instance_id: str = ""
    capabilities: Sequence[str] = dataclasses.field(default_factory=tuple)
    protocol_min: str = PROTOCOL_VERSION
    protocol_max: str = PROTOCOL_VERSION
    sdk_version: str = SDK_VERSION

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="metadata"))


@dataclasses.dataclass(frozen=True, slots=True)
class ConfigValueV1:
    name: str
    value_type: str
    default: JSONValue
    description: str = "No description"
    sensitive: bool = False
    choices: Sequence[JSONValue] = dataclasses.field(default_factory=tuple)

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="config"))


@dataclasses.dataclass(frozen=True, slots=True)
class MessageV1:
    id: int
    chat_id: int
    sender_id: int | None = None
    text: str = ""
    outgoing: bool = False
    chat_type: str = "private"
    date_unix_ms: int = 0
    edited_unix_ms: int = 0
    reply_to_message_id: int | None = None
    thread_id: int | None = None
    mentioned: bool = False
    forwarded: bool = False
    media_kind: str | None = None
    via_bot_id: int | None = None

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="message"))

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> MessageV1:
        return cls(
            id=_require_int(value.get("id"), "message.id"),
            chat_id=_require_int(value.get("chat_id"), "message.chat_id"),
            sender_id=_nullable_int(value.get("sender_id"), "message.sender_id"),
            text=_optional_str(value.get("text"), "", "message.text"),
            outgoing=_optional_bool(value.get("outgoing"), False, "message.outgoing"),
            chat_type=_optional_str(value.get("chat_type"), "private", "message.chat_type"),
            date_unix_ms=_optional_int(value.get("date_unix_ms"), 0, "message.date_unix_ms"),
            edited_unix_ms=_optional_int(value.get("edited_unix_ms"), 0, "message.edited_unix_ms"),
            reply_to_message_id=_nullable_int(
                value.get("reply_to_message_id"), "message.reply_to_message_id"
            ),
            thread_id=_nullable_int(value.get("thread_id"), "message.thread_id"),
            mentioned=_optional_bool(value.get("mentioned"), False, "message.mentioned"),
            forwarded=_optional_bool(value.get("forwarded"), False, "message.forwarded"),
            media_kind=_nullable_str(value.get("media_kind"), "message.media_kind"),
            via_bot_id=_nullable_int(value.get("via_bot_id"), "message.via_bot_id"),
        )


@dataclasses.dataclass(frozen=True, slots=True)
class UpdateV1:
    id: str
    kind: str
    message: MessageV1 | None = None
    data: Mapping[str, JSONValue] = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="update"))


@dataclasses.dataclass(frozen=True, slots=True)
class CommandV1:
    name: str
    arguments: str
    prefix: str
    message: MessageV1

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="command"))


@dataclasses.dataclass(frozen=True, slots=True)
class ActionV1:
    kind: ActionKind
    target: Mapping[str, JSONValue]
    parameters: Mapping[str, JSONValue] = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict[str, JSONValue]:
        return dict(_require_object(_drop_none(self), field="action"))


@dataclasses.dataclass(frozen=True, slots=True)
class ActionResultV1:
    value: JSONValue = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> ActionResultV1:
        return cls(value=ensure_json_value(payload.get("value"), field="result.value"))


def _require_object(value: Any, *, field: str) -> dict[str, JSONValue]:
    if not isinstance(value, Mapping):
        raise ProtocolError(f"{field} must be a JSON object")
    checked = ensure_json_value(value, field=field)
    if not isinstance(checked, dict):
        raise ProtocolError(f"{field} must be a JSON object")
    return checked


def _require_str(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{field} must be a non-empty string")
    return value


def _optional_str(value: Any, default: str, field: str) -> str:
    if value is None:
        return default
    if not isinstance(value, str):
        raise ProtocolError(f"{field} must be a string")
    return value


def _nullable_str(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _optional_str(value, "", field)


def _require_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProtocolError(f"{field} must be an integer")
    return value


def _optional_int(value: Any, default: int, field: str) -> int:
    if value is None:
        return default
    return _require_int(value, field)


def _nullable_int(value: Any, field: str) -> int | None:
    if value is None:
        return None
    return _require_int(value, field)


def _optional_bool(value: Any, default: bool, field: str) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise ProtocolError(f"{field} must be a boolean")
    return value


__all__ = [
    "PROTOCOL_NAME",
    "PROTOCOL_VERSION",
    "SDK_VERSION",
    "ActionKind",
    "ActionResultV1",
    "ActionV1",
    "CommandV1",
    "ConfigValueV1",
    "EnvelopeV1",
    "HandlerKind",
    "HandlerSpecV1",
    "JSONValue",
    "MessageV1",
    "PluginMetadataV1",
    "RPCErrorV1",
    "UpdateV1",
    "ensure_json_value",
]

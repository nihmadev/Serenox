# Serenox Python sidecar

This directory contains the optional, process-isolated compatibility host and
the small `serenox_sdk` package used by Python plugins. The host never embeds
Python in the Go daemon. It connects to a daemon-owned local socket and exchanges
versioned, length-prefixed JSON frames.

The compatibility surface is intentionally finite. Missing legacy attributes
raise `UnsupportedAPIError` with a replacement hint rather than failing later
with an ambiguous `AttributeError`.

```sh
uv sync --locked --group dev
uv run ruff check .
uv run pyrefly check src tests
uv run python -m unittest discover -s tests -t .
```

